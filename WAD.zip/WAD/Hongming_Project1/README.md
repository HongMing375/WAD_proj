# WAD Project
Name: Chan Hong Ming  <br>
Module Group: L2 <br>
<br> 
## Project Title
MovieHub <br>
<br> 
## Key Features
<ul>
    <li>Add movies</li>
    <li>Search movies by name</li>
    <li>Show all movies</li>
    <li>Delete movies by name</li>
    <li>Update movie by ID</li>
    <li>Image upload</li>
    <li>Add genre</li>
    <li>Update genre</li>
    <li>Delete genre</li>
    <li>Search for genre by name</li>
    <li>Email notification when CRUD for movies</li>
</ul>
<br> 
## External APIs[^1] that you would like to use
Describe which external APIs that you would like to use and how you would use them.<br>
<ul>
    <li>Use Netflix API and i will use it to search shows</li>
    <li>Use IMBD API to display the top 250 movies</li>
</ul>
<br> 
## External node modules[^1] that you would like to use
Describe which node modules that you would like to use and how you would use them.<br>
<ul>
    <li>Use a node module called nodemailer to send the email notifcaiton when user add movies and other features</li>
    <li>Use a node module called multer which can allow user to upload image and save the image into a folder</li>
</ul>
<br>
## References
Put all the relevant reference links that you have used for your project.<br>
<ul>
    <li>https://www.npmjs.com/package/multer</li>
    <li>https://www.npmjs.com/package/nodemailer</li>
</ul>
<br>
<br>
:warning: This repository includes gitignore file which will not commit certain files or folders (especially node_modules folder) for a node.js project into the repository.  
**Please do not remove the .gitignore file as it will help to minimize the size of the project in the repository.** 
<br>
[^1]: Note that you can still change them at the later stage of the project if you find new APIs or node modules.
