[
  { "name": "Action" },
  { "name": "Comedy" },
  { "name": "Drama" },
  { "name": "Horror" },
  { "name": "Sci-Fi" },
  { "name": "Thriller" },
  { "name": "Romance" },
  { "name": "Fantasy" },
  { "name": "Adventure" },
  { "name": "Animation" }
]