[
    {
        "username" : "hong ming",
        "email" : "chanhongming00@gmail.com",
        "password" : "password123",
        "role" : "admin"
    }
]