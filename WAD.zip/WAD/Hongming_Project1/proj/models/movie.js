const mongoose = require('mongoose');

const MovieSchema = new mongoose.Schema({
    title: { type: String, required: true, unique: true},
    description: String,
    releaseYear: Number,
    poster: String,
    genre: { type: mongoose.Schema.Types.ObjectId, ref: 'genre' },
});

module.exports = mongoose.model('movie', MovieSchema);