const express = require('express');
const router = express.Router();
const db = require("./services/dbservice.js");
const crypto = require('crypto');
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const upload = require("./upload.js");

db.connect()
.then(function(response){
    console.log(response);
})
.catch(function(error){
    console.log(error.message);
});

router.use(express.urlencoded({
    extended: true
}));

//search for movies using the netlfix api
router.get('/api/netflix/search/:data',function(req,res) {
    let data = req.params.data;
    db.SearchNetflix(data)
    .then(function(response){
        res.status(200).json(response);
    })
    .catch(function(error){
        res.status(500).json({"message":error.message});
    });
})

//search for movie critics
router.get('/api/movies/top250',function(req,res) {
    db.ShowTop250Movies()
    .then(function(response){
        res.status(200).json(response);
    })
    .catch(function(error){
        res.status(500).json({"message":error.message});
    });
})

//add movies and send email notification
router.post('/api/movie/add', function(req, res) {
    let data = req.body;
    if (!emailRegex.test(data.email)) {
        return res.status(400).json({ message: "Invalid email address" });
    }
    else {
        db.addMovie(data.title,  data.description, data.releaseYear, data.genreId)
        .then(function(response){
            db.emailNotificaiton(data.email, `<p>New movie: ${data.title} has been added.</p>`, "New Movie Added");
            res.status(200).json({"message":response});
        })
        .catch(function(error){
            res.status(500).json({"message":error.message});
        });
    }
})

//search for movies by name
router.get('/api/movie/search/:data',function(req,res) {
    let data = req.params.data;
    db.searchMoviebyName({title: data})
    .then(function(response){
        res.status(200).json(response);
    })
    .catch(function(error){
        res.status(500).json({"message":error.message});
    });
})

router.get('/api/movie/:id',function(req,res) {
    let id = req.params.id;
    db.searchMoviebyID(id)
    .then(function(response){
        res.status(200).json(response);
    })
    .catch(function(error){
        res.status(500).json({"message":error.message});
    });
})

//search all movies
router.get('/api/movie/search',function(req,res) {
    db.searchallMovies()
    .then(function(response){
        res.status(200).json(response);
    })
    .catch(function(error){
        res.status(500).json({"message":error.message});
    });
})

//delete movies by Name and send email notification
router.delete('/api/movie/delete',function(req,res){
    let data = req.body;

    if (!emailRegex.test(data.email)) {
        return res.status(400).json({ message: "Invalid email address" });
    }
    else {
        db.deleteMovieByName(data.title)
        .then(function(response){
            db.emailNotificaiton(data.email, `<p>Movie removed: ${data.title} has been removed.</p>`, "Removed Movie");
            res.status(200).json({"message":response});
        })
        .catch(function(error){
            res.status(500).json({"message":error.message});
        });
    }
})

//update movie by ID
router.put('/api/movie/update/:id',function(req,res) {
    let id = req.params.id;
    let data = req.body;
    if (!emailRegex.test(data.email)) {
        return res.status(400).json({ message: "Invalid email address" });
    }
    else {
        db.updateMoviebyID(id,{title: data.title, description: data.description, releaseYear: data.releaseYear, genre: data.genreId})
        .then(function(response){
            db.emailNotificaiton(data.email, `<p>Movie updated: ${data.title} has been updated.</p>`, "Updated Movie");
            res.status(200).json({"message":response});
        })
        .catch(function(error){
            res.status(500).json({"message":error.message});
        });
    }
})

//image upload
router.put('/api/movie/poster/add', upload.single('poster'), (req, res) => {
    const data = req.body;
    const poster = req.file ? req.file.filename : null;

    if (!data.movieID) return res.status(400).json({ message: "movieID is required" });

    db.addPoster(data.movieID, { poster: poster })
    .then(function(response){
        res.status(200).json({"message":response});
    })
    .catch(function(error){
        res.status(500).json({"message":error.message});
    });
});

//add genre
router.post('/api/genre/add', function(req, res) {
    let data = req.body;
    
    db.AddGenre(data.name)
    .then(function(response){
        res.status(200).json({"message":response});
    })
    .catch(function(error){
        res.status(500).json({"message":error.message});
    });
})

//update genre
router.put('/api/genre/update/:id',function(req,res) {
    let id = req.params.id;
    let data = req.body;
    
    db.updateGenrebyID(id,{name: data.name})
    .then(function(response){
        res.status(200).json({"message":response});
    })
    .catch(function(error){
        res.status(500).json({"message":error.message});
    });
})

//delete genre
router.delete('/api/genre/delete',function(req,res){
    let data = req.body;

    db.deleteGenreByName(data.name)
    .then(function(response){
        res.status(200).json({"message":response});
    })
    .catch(function(error){
        res.status(500).json({"message":error.message});
    });
})

//search for genre by name
router.get('/api/genre/search/',function(req,res) {
    db.searchGenre()
    .then(function(response){
        res.status(200).json(response);
    })
    .catch(function(error){
        res.status(500).json({"message":error.message});
    });
})

module.exports = router;