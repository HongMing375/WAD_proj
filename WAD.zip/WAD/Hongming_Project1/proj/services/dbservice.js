const mongoose = require('mongoose');
const fetch = require('node-fetch');
const movie = require("../models/movie.js");
const user = require("../models/users.js");
const genre = require("../models/genre.js");
const nodemailer = require('nodemailer');

let db = {
    async connect() {
        try {
            await mongoose.connect('mongodb://127.0.0.1:27017/WAD_Proj');
            return "Connected to Mongo DB";
        }
        catch(e) {
            console.log(e.message);
            throw new Error("Error connecting to Mongo DB");
        }
    },

    async ShowTop250Movies() {
        const options = {
            method: 'GET',
            headers: {
                'x-rapidapi-key': '6878e3ef81msh76601bb127fa43ap1a888fjsn7827b34d5dc9',
                'x-rapidapi-host': 'imdb236.p.rapidapi.com'
            }
        };

        try {
            const response = await fetch(`https://imdb236.p.rapidapi.com/api/imdb/top250-movies`, options);
            result = await response.json();
            result = result.map(item => ({
                title: item.primaryTitle,
                description: item.description,
                releaseYear: item.startYear,
                genres: item.genres,
                average_score: item.averageRating
            }));
            return result;
        } catch (error) {
            console.error(error);
        }
    },

    async SearchNetflix(data) {
        const options = {
            method: 'GET',
            headers: {
                'x-rapidapi-key': '6878e3ef81msh76601bb127fa43ap1a888fjsn7827b34d5dc9',
                'x-rapidapi-host': 'netflix54.p.rapidapi.com'
            }
        };

        try {
            let result = await fetch(`https://netflix54.p.rapidapi.com/search/?query=${encodeURIComponent(data)}&offset=0&limit_titles=50&limit_suggestions=20&lang=en`, options);  
            result = await result.json();
            result = result.titles.filter(item => item.jawSummary.title.toLowerCase().includes(data.toLowerCase())).map(item => ({
                title: item.jawSummary.title,
                description: item.jawSummary.contextualSynopsis.text,
                releaseYear: item.jawSummary.releaseYear,
                genres: item.jawSummary.genres,
            }));

            return result;
        }
        catch(e) {
            console.log(e.message);
            throw new Error("Invalid Search");
        }
    },
    
    async addMovie(title, description, releaseYear, genreId) {
        try {
            await movie.create({
                title: title,
                description: description,
                releaseYear: releaseYear,
                genre: genreId,               
            });
            return `Status: ${title} has been added`;
        }
        catch(e) {
            console.log(e.message);
            throw new Error(`Status: ${title} was not added.`);
        }
    },

    async searchMoviebyName(data) {
        try {
            let results = await movie.find({ title: new RegExp(data,'i') }).populate('genre');
            return results; 
        }
        catch(e) {
            console.log(e.message);
            throw new Error(`Status: ${title} was not added.`);
        }
    },

    async searchMoviebyID(id) {
        try {
            let results = await movie.findById(id).populate('genre');
            return results; 
        }
        catch(e) {
            console.log(e.message);
            throw new Error(`Status: ${title} was not added.`);
        }
    },

    async searchallMovies() {
        try {
            let results = await movie.find().populate('genre');
            return results; 
        }
        catch(e) {
            console.log(e.message);
            throw new Error(`Status: ${title} was not added.`);
        }
    },

    async deleteMovieByName(data) {
        try {
            let result = await movie.findOneAndDelete({title: data});
            if (!result) return "Unable to find a movie to delete.";
            else return "Movie is deleted!";
        }
        catch(e) {
            console.log(e.message);
            throw new Error("Error deleting movie");
        }
    },

    async updateMoviebyID(id, updates) {
        try {
            let result = await movie.findByIdAndUpdate(id, updates)
            if (!result) return "Unable to find movie to update.";
            else return "Movie is updated!";
        }
        catch(e) {
            console.log(e.message);
            throw new Error("Error updating Movie");
        }
    },

    async emailNotificaiton(toEmail, message, subject) {
        try {
            const transport = nodemailer.createTransport({
                host: "sandbox.smtp.mailtrap.io",
                port: 2525,
                secure: false,
                auth: {
                    user: "4b396e50ea4209",
                    pass: "0a71d78f5bfc77"
                }
            });

            const emailContent = {
                from: '"Movie App" <no-reply@movieapp.com>',
                to: toEmail,
                subject: subject,
                text: message,
                html: message
            };

            await transport.sendMail(emailContent);
            return "Email sent successfully!";
        }
        catch(e) {
            console.log(e.message);
            throw new Error("Error sending notification");
        }
    },

    async addPoster(id, updates) {
        try {
            let result = await movie.findByIdAndUpdate(id, updates)
            if (!result) return "Unable to find movie.";
            else return "Poster is updated!";
        }
        catch(e) {
            console.log(e.message);
            throw new Error("Error adding poster");
        }
    },

    async AddGenre(name) {
        try {
            await genre.create({
                name: name,             
            });
            return `Status: ${name} has been added`;
        }
        catch(e) {
            console.log(e.message);
            throw new Error(`Status: ${name} was not added.`);
        }
    },

    async deleteGenreByName(data) {
        try {
            let result = await genre.findOneAndDelete({name: data});
            if (!result) return "Unable to find a genre to delete.";
            else return "Genre is deleted!";
        }
        catch(e) {
            console.log(e.message);
            throw new Error("Error deleting genre");
        }
    },

    async searchGenre() {
        try {
            let results = await genre.find();
            return results; 
        }
        catch(e) {
            console.log(e.message);
            throw new Error(`Error finding Genre`);
        }
    },

    async updateGenrebyID(id, updates) {
        try {
            let result = await genre.findByIdAndUpdate(id, updates)
            if (!result) return "Unable to find genre to update.";
            else return "Genre is updated!";
        }
        catch(e) {
            console.log(e.message);
            throw new Error("Error updating genre");
        }
    },
}

module.exports = db;
